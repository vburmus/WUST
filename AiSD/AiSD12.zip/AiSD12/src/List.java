public  enum List{
    Wrocław,
    Oława,
    Brzeg,
    Nysa,
    Opole
    }
