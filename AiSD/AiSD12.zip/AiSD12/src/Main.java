public class Main {
    public static Graph make(){
        Graph graf = new Graph(5);
        graf.addEdge(0, 1, 10);
        graf.addEdge(0, 3, 30);
        graf.addEdge(0, 4, 100);
        graf.addEdge(1, 2, 50);
        graf.addEdge(2, 4, 10);
        graf.addEdge(3, 2, 20);
        graf.addEdge(3, 4, 60);
        return graf;
    }
    public static void main (String [] args) {
        Graph graf = make();
        graf.showListe();
        String miasto = "Wrocław";
        graf.djikstra(miasto);
        graf.DFS(miasto);
    }
}
